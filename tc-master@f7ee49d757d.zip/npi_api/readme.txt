https://onejenkins.verizon.com/nts/job/NTS.NPI.NPIAPI.UAT.BUILD

Maven Goals:
clean install //Do this in root project directory
package spring-boot:repackage


//only to docker on jenkins
package spring-boot:repackage -Ddocker.username=jolokia -Ddocker.password=s!cr!t docker:build //Do this in mvc directory