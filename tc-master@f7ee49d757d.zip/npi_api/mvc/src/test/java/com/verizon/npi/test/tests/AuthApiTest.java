package com.verizon.npi.test.tests;

import com.verizon.npi.mvc.config.authentication.SecurityConstants;
import com.verizon.npi.mvc.dao.oracle.RoleRepository;
import com.verizon.npi.test.config.AbstractApplicationTest;
import com.verizon.npi.test.config.UtilityMethods;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MvcResult;

import static org.assertj.core.api.Java6Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
public class AuthApiTest extends AbstractApplicationTest {
    @Autowired private UtilityMethods utilityMethods;
    @Autowired private RoleRepository roleRepository;
    @Autowired private SecurityConstants securityConstants;

    @Before
    public void preStep(){
    }

    @Test
    public void refreshADMIN() throws Exception{
        MvcResult result = mvc.perform(post("/auth/refresh")
                .headers(adminHeader()))
                .andExpect(status().isOk())
                .andReturn();
        assertThat(objectMapper.readTree(result.getResponse().getContentAsString()).get("access_token").asText()).isNotNull().isNotEmpty();
    }

    @Test
    public void refreshUSER() throws Exception{
        MvcResult result = mvc.perform(post("/auth/refresh")
                .headers(userHeader()))
                .andExpect(status().isOk())
                .andReturn();
        assertThat(objectMapper.readTree(result.getResponse().getContentAsString()).get("access_token").asText()).isNotNull().isNotEmpty();
    }


    @Test
    public void refreshVIEWER() throws Exception{
        MvcResult result = mvc.perform(post("/auth/refresh")
                .headers(viewerHeader()))
                .andExpect(status().isOk())
                .andReturn();
        assertThat(objectMapper.readTree(result.getResponse().getContentAsString()).get("access_token").asText()).isNotNull().isNotEmpty();
    }
}
