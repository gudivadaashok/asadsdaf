package com.verizon.npi.test.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.verizon.npi.mvc.Application;
import com.verizon.npi.mvc.config.authentication.SecurityConstants;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import javax.servlet.Filter;
import java.io.IOException;

import static com.verizon.npi.mvc.core.NpiConfiguration.NPI_AUTH_HEADER;


@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = Application.class)
@SuppressWarnings("unchecked")
public abstract class AbstractApplicationTest {
    @Autowired private WebApplicationContext context;
    @Autowired private Filter springSecurityFilterChain;
    @Autowired private SecurityConstants securityConstants;
    @Autowired private UtilityMethods utilityMethods;
    @Autowired public Environment environment;

    protected MockMvc mvc;
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());
    @LocalServerPort
    protected int port;
        protected String baseUrl;
    public ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void before() throws IOException {
            this.mvc = MockMvcBuilders
                    .webAppContextSetup(context)
                    .addFilters(springSecurityFilterChain)
                    .build();
        this.baseUrl = "http://localhost:"+this.port;
    }

    @Ignore
    public void init(){
        assert(true);
    }
    public HttpHeaders systemHeader(){
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(securityConstants.getHEADER_STRING(),utilityMethods.getToken(securityConstants.getSYS_SPINDLE_USER(),
                securityConstants.getSYS_SPINDLE_PASSWORD(),this.baseUrl+"/auth/login"));
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }
    public HttpHeaders adminHeader(){
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(securityConstants.getHEADER_STRING(),utilityMethods.getToken("admin@verizon.com","admin",this.baseUrl+"/auth/login"));
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }
    public HttpHeaders userHeader(){
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(securityConstants.getHEADER_STRING(),utilityMethods.getToken("user@verizon.com","user",this.baseUrl+"/auth/login"));
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }
    public HttpHeaders viewerHeader(){
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(securityConstants.getHEADER_STRING(),utilityMethods.getToken("viewer@verizon.com","viewer",this.baseUrl+"/auth/login"));
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }
    public HttpHeaders customHeader(String username, String password){
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(securityConstants.getHEADER_STRING(),utilityMethods.getToken(username,password,this.baseUrl+"/auth/login"));
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }

    public HttpHeaders apiHeader(String token){
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set(NPI_AUTH_HEADER, token);
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        return httpHeaders;
    }
}
