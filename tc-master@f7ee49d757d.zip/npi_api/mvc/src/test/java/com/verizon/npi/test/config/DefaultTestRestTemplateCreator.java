package com.verizon.npi.test.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.verizon.npi.mvc.config.authentication.SecurityConstants;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;

import java.util.Collections;
import java.util.List;

public class DefaultTestRestTemplateCreator {

    private TestRestTemplate testRestTemplate;
    private SecurityConstants securityConstants;

    public DefaultTestRestTemplateCreator(SecurityConstants securityConstants) {
        this.securityConstants = securityConstants;
    }

    public void setTestRestTemplate(String username, String password, String loginurl){
        String token = getToken(username, password, loginurl);
        TestRestTemplate testRestTemplate = new TestRestTemplate();
        testRestTemplate.getRestTemplate().setInterceptors(
                Collections.singletonList((request, body, execution) -> {
                    request.getHeaders()
                            .add("Authorization", token);
                    return execution.execute(request, body);
                }));

        this.testRestTemplate = testRestTemplate;
    }

    private String getToken(String username, String password, String url){
        ObjectNode input = new ObjectMapper().createObjectNode();
        input.put("username", username);
        input.put("password", password);
        TestRestTemplate tokenAuth = new TestRestTemplate();
        ResponseEntity<String> response = tokenAuth.exchange(url, HttpMethod.POST, getRequest(input), String.class);

        return response.getHeaders().getFirst(securityConstants.getHEADER_STRING());
    }

    private HttpEntity<String> getRequest(Object post){
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(acceptableMediaType());
        return new HttpEntity(post, headers);
    }
    private List<MediaType> acceptableMediaType(){
        return Collections.singletonList(MediaType.ALL);
    }


    public TestRestTemplate getTestRestTemplate() {
        return testRestTemplate;
    }
}
