package com.verizon.npi.test.config;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.verizon.npi.mvc.config.authentication.SecurityConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.env.Environment;
import org.springframework.http.*;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.List;


@Component
public class UtilityMethods {

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private SecurityConstants securityConstants;

    @Autowired
    private Environment environment;

    public UsernamePasswordAuthenticationToken getPrincipal(String username) {

        UserDetails user = userDetailsService.loadUserByUsername(username);

        UsernamePasswordAuthenticationToken authentication =
                new UsernamePasswordAuthenticationToken(
                        user,
                        user.getPassword(),
                        user.getAuthorities());

        return authentication;
    }

    public MockHttpSession getSession(String user) {
        UsernamePasswordAuthenticationToken principal =
                getPrincipal(user);
        MockHttpSession session = new MockHttpSession();
        session.setAttribute(
                HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY,
                new MockSecurityContext(principal));
        SecurityContextHolder.getContext().setAuthentication(principal);
        return session;
    }

    public String getToken(String username, String password, String url){
        ObjectNode input = new ObjectMapper().createObjectNode();
        input.put("username", username);
        input.put("password", password);
        TestRestTemplate tokenAuth = new TestRestTemplate();
        ResponseEntity<JsonNode> response = tokenAuth.exchange(url, HttpMethod.POST, getRequest(input), JsonNode.class);
        return securityConstants.getTOKEN_PREFIX() + response.getBody().get("access_token").asText();
    }

    private HttpEntity<String> getRequest(Object post){
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(acceptableMediaType());
        return new HttpEntity(post, headers);
    }

    private List<MediaType> acceptableMediaType(){
        return Collections.singletonList(MediaType.ALL);
    }

}
