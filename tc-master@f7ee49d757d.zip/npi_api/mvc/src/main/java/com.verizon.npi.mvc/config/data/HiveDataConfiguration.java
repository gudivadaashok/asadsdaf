package com.verizon.npi.mvc.config.data;

import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.HashMap;

/**
 * Created by Cherla, Arun on 5/6/2018.
 */
@Configuration
@EnableJpaRepositories(
        basePackages = "com.verizon.npi.mvc.dao.hive",
        entityManagerFactoryRef = "hiveEntityManager",
        transactionManagerRef = "hiveTransactionManager"
)
public class HiveDataConfiguration {
    private static final Logger log = LoggerFactory
            .getLogger(HiveDataConfiguration.class.getName());

    @Value("${spring.datasource.hive.username}")
    private String hive_username;

    @Value("${spring.datasource.hive.password}")
    private String hive_password;

    @Value("${spring.datasource.hive.url}")
    private String hive_url;

    @Bean(name="HIVEDataSource")
    public DataSource npidatasource() throws SQLException {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setDriverClassName("org.apache.hive.jdbc.HiveDriver");
        dataSource.setUsername(hive_username);
        dataSource.setPassword(hive_password);
        dataSource.setJdbcUrl(hive_url);
        dataSource.setPoolName("HIVE_POOL");
        dataSource.setMaximumPoolSize(100);
        dataSource.setMinimumIdle(1);
        return dataSource;
    }

    @Bean("HIVEJDBC")
    public JdbcTemplate npiDataSourceJdbc(@Qualifier("HIVEDataSource") DataSource adapter) throws SQLException {
        JdbcTemplate npi = new JdbcTemplate(adapter);
        return npi;
    }

    @Bean("hiveEntityManager")
    public LocalContainerEntityManagerFactoryBean hiveEntityManager() throws SQLException {
        LocalContainerEntityManagerFactoryBean em
                = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(npidatasource());
        em.setPackagesToScan(
                new String[] { "com.verizon.npi.mvc.models.hive" });

        HibernateJpaVendorAdapter vendorAdapter
                = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect",
                "org.hibernate.dialect.Oracle10gDialect");
        //properties.put("hibernate.hbm2ddl.auto", "validate");
        em.setJpaPropertyMap(properties);
        return em;
    }

    @Bean("hiveTransactionManager")
    public PlatformTransactionManager hiveTransactionManager() throws SQLException {
        JpaTransactionManager transactionManager
                = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(
                hiveEntityManager().getObject());
        return transactionManager;
    }
}
