package com.verizon.npi.mvc.config.data;

import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.HashMap;

/**
 * Created by Cherla, Arun on 5/6/2018.
 */
@Configuration
@EnableJpaRepositories(
        basePackages = "com.verizon.npi.mvc.dao.oracle",
        entityManagerFactoryRef = "npiEntityManager",
        transactionManagerRef = "npiTransactionManager"
)
public class DefaultDataConfiguration {
    private static final Logger log = LoggerFactory
            .getLogger(DefaultDataConfiguration.class.getName());

    @Value("${spring.datasource.npi.username}")
    private String npi_username;

    @Value("${spring.datasource.npi.password}")
    private String npi_password;

    @Value("${spring.datasource.npi.url}")
    private String npi_url;

    @Bean(name="NPIDataSource")
    @Primary
    public DataSource npidatasource() throws SQLException {
        HikariDataSource dataSource = new HikariDataSource();
        dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
        dataSource.setUsername(npi_username);
        dataSource.setPassword(npi_password);
        dataSource.setJdbcUrl(npi_url);
        dataSource.setPoolName("NPI_POOL");
        dataSource.setMaximumPoolSize(100);
        dataSource.setMinimumIdle(1);
        dataSource.setAutoCommit(true);
        return dataSource;
    }

    @Bean("NPIJDBC")
    @Primary
    public JdbcTemplate npiDataSourceJdbc(@Qualifier("NPIDataSource") DataSource adapter) throws SQLException {
        JdbcTemplate npi = new JdbcTemplate(adapter);
        return npi;
    }

    @Bean("npiEntityManager")
    @Primary
    public LocalContainerEntityManagerFactoryBean npiEntityManager() throws SQLException {
        LocalContainerEntityManagerFactoryBean em
                = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(npidatasource());
        em.setPackagesToScan(
                new String[] { "com.verizon.npi.mvc.models.oracle" });

        HibernateJpaVendorAdapter vendorAdapter
                = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("hibernate.dialect",
                "org.hibernate.dialect.Oracle10gDialect");
        properties.put("hibernate.hbm2ddl.auto", "create");
        em.setJpaPropertyMap(properties);
        return em;
    }

    @Bean("npiTransactionManager")
    @Primary
    public PlatformTransactionManager npiTransactionManager() throws SQLException {
        JpaTransactionManager transactionManager
                = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(
                npiEntityManager().getObject());
        return transactionManager;
    }


}
