package com.verizon.npi.mvc.config.authentication;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.net.UnknownHostException;

@Component
public class SecurityConstants {
    @Value("${spring.application.name}")
    private String APP_NAME;
    @Value("${jwt.secret}")
    public String SECRET;
    @Value("${jwt.expires_in}")
    public long EXPIRATION_TIME;
    @Value("${jwt.token_prefix}")
    public String TOKEN_PREFIX;
    @Value("${jwt.header}")
    public String HEADER_STRING;
    @Value("${npi.npiUser}")
    private String SYS_SPINDLE_USER;
    @Value("${npi.npiPassword}")
    private String SYS_SPINDLE_PASSWORD;
    @Value("${PORT}")
    private String currentPort;
    private String JSESSIONID_HEADER = "JSESSIONID";

    public String getCurrentPort() {
        return currentPort;
    }

    public String getMicroserviceUrl() {
        try {
            return "http://" + InetAddress.getLocalHost().getHostAddress() + ":" + currentPort;
        } catch (UnknownHostException e) {
            return "http://127.0.0.1:" + currentPort;
        }
    }

    public String getSECRET() {
        return SECRET;
    }

    public long getEXPIRATION_TIME() {
        return EXPIRATION_TIME;
    }

    public String getTOKEN_PREFIX() {
        return TOKEN_PREFIX;
    }

    public String getHEADER_STRING() {
        return HEADER_STRING;
    }

    public String getAPP_NAME() {
        return APP_NAME;
    }

    public String getSYS_SPINDLE_USER() {
        return SYS_SPINDLE_USER;
    }

    public String getSYS_SPINDLE_PASSWORD() {
        return SYS_SPINDLE_PASSWORD;
    }

    public String getJSESSIONID_HEADER() {
        return JSESSIONID_HEADER;
    }
}
