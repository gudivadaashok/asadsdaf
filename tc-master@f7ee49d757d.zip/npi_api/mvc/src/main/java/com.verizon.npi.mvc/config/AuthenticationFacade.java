package com.verizon.npi.mvc.config;


import com.verizon.npi.mvc.config.service.IAuthenticationFacade;
import com.verizon.npi.mvc.dao.oracle.UserRepository;
import com.verizon.npi.mvc.models.oracle.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

@Component
public class AuthenticationFacade implements IAuthenticationFacade {

    @Autowired
    private UserRepository userRepository;

    @Override
    public Authentication getAuthentication() {
        return SecurityContextHolder.getContext().getAuthentication();
    }

    @Override
    public User getUser(){
        return userRepository.findByUsername(getAuthentication().getName()).get();
    }
}
