package com.verizon.npi.mvc.config.service;

import com.verizon.npi.mvc.models.oracle.User;
import org.springframework.security.core.Authentication;

public interface IAuthenticationFacade {
    Authentication getAuthentication();

    User getUser();
}
