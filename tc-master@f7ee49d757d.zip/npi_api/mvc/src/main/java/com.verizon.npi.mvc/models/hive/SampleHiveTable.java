package com.verizon.npi.mvc.models.hive;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * Created by Cherla, Arun on 5/11/2018.
 */
@Entity
@Table(name = "np_actions")
public class SampleHiveTable {

    @EmbeddedId
    @Column(name = "action_id")
    private Long action_id;
    @Column(name = "event_supertype")
    private String event_supertype;
    @Column(name = "description")
    private String description;
    @Column(name = "tag")
    private String tag;
    @Column(name = "message_id")
    private Long message_id;

    public SampleHiveTable() {
    }

    public Long getAction_id() {
        return action_id;
    }

    public void setAction_id(Long action_id) {
        this.action_id = action_id;
    }

    public String getEvent_supertype() {
        return event_supertype;
    }

    public void setEvent_supertype(String event_supertype) {
        this.event_supertype = event_supertype;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Long getMessage_id() {
        return message_id;
    }

    public void setMessage_id(Long message_id) {
        this.message_id = message_id;
    }
}
