package com.verizon.npi.mvc.models.sub;

/**
 * Created by Cherla, Arun on 4/14/2018.
 */
public enum ROLE_TYPE {
    USER, ADMIN, VIEWER, SYSTEM
}
