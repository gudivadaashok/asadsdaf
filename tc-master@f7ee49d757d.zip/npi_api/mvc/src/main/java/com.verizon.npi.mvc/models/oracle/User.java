package com.verizon.npi.mvc.models.oracle;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.annotations.Type;
import org.hibernate.validator.constraints.Email;

import javax.persistence.*;
import java.util.Set;

/**
 * Created by Cherla, Arun on 12/26/2017.
 */
@Entity
@Table(name = "npi_user")
@JsonIgnoreProperties(ignoreUnknown = true)
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Email
    @Column(name = "email", nullable = false, unique = true)
    private String email;
    @Email
    @Column(name = "username", nullable = false, unique = true)
    private String username;
    @Column(name = "password", nullable = false)
    private String password;
    @Column(name = "enabled")
    @Type(type="true_false")
    private boolean enabled;
    @ManyToMany
    @JoinTable(name = "npi_user_role", joinColumns = @JoinColumn(name = "user_id"), inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles;
    @Column(name = "createdDate")
    private Long createdDate;
    @Column(name = "lastUpdatedDate")
    private Long lastUpdatedDate;

    @PreUpdate
    @PrePersist
    public void updateTimeStamps() {
        lastUpdatedDate = System.currentTimeMillis();
        if (createdDate == null) {
            createdDate = System.currentTimeMillis();
        }
    }

    public User() {
    }

    public User(String username, String password, Set<Role> roles) {
        this.email = username;
        this.username = username;
        this.password = password;
        this.roles = roles;
    }

    public User(String username, String password) {
        this.email = username;
        this.username = username;
        this.password = password;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

}