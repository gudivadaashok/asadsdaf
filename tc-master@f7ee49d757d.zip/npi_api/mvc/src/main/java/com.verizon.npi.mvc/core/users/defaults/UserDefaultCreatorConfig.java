package com.verizon.npi.mvc.core.users.defaults;

import com.verizon.npi.mvc.config.authentication.SecurityConstants;
import com.verizon.npi.mvc.core.users.UserService;
import com.verizon.npi.mvc.dao.oracle.RoleRepository;
import com.verizon.npi.mvc.dao.oracle.UserRepository;
import com.verizon.npi.mvc.models.oracle.Role;
import com.verizon.npi.mvc.models.oracle.User;
import com.verizon.npi.mvc.models.sub.ROLE_TYPE;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.HashSet;

/**
 * Created by Cherla, Arun on 12/27/2017.
 */

@Configuration
public class UserDefaultCreatorConfig {

    private UserService userService;
    private RoleRepository roleRepository;
    private UserRepository userRepository;
    private SecurityConstants securityConstants;

    @Autowired
    public UserDefaultCreatorConfig(UserService userService, RoleRepository roleRepository, UserRepository userRepository, SecurityConstants securityConstants) {
        this.userService = userService;
        this.roleRepository = roleRepository;
        this.userRepository = userRepository;
        this.securityConstants = securityConstants;
    }

    @PostConstruct
    public void createDefaultUserSettings(){
        this.createDefaultRoles();
        if(userRepository.findAll().size() == 0)
            this.createDefaultUsers();
        if(!userRepository.findByEmail(securityConstants.getSYS_SPINDLE_USER()).isPresent())
            userService.save(new User(securityConstants.getSYS_SPINDLE_USER(), securityConstants.getSYS_SPINDLE_PASSWORD(), new HashSet<>(Arrays.asList(roleRepository.findByRole(ROLE_TYPE.SYSTEM).get()))));
    }

    public void createDefaultRoles() {
        if (!roleRepository.findByRole(ROLE_TYPE.ADMIN).isPresent())
            roleRepository.save(new Role(ROLE_TYPE.ADMIN, true));
        if (!roleRepository.findByRole(ROLE_TYPE.USER).isPresent())
            roleRepository.save(new Role(ROLE_TYPE.USER, true));
        if (!roleRepository.findByRole(ROLE_TYPE.VIEWER).isPresent())
            roleRepository.save(new Role(ROLE_TYPE.VIEWER, true));
        if (!roleRepository.findByRole(ROLE_TYPE.SYSTEM).isPresent())
            roleRepository.save(new Role(ROLE_TYPE.SYSTEM, true));
    }

    public void createDefaultUsers() {
        if(!userService.findByUsername("admin@verizon.com").isPresent())
            userService.save(new User("admin@verizon.com", "admin", new HashSet<>(Arrays.asList(roleRepository.findByRole(ROLE_TYPE.ADMIN).get()))));
        if(!userService.findByUsername("user@verizon.com").isPresent())
            userService.save(new User("user@verizon.com","user", new HashSet<>(Arrays.asList(roleRepository.findByRole(ROLE_TYPE.USER).get()))));
        if(!userService.findByUsername("viewer@verizon.com").isPresent())
            userService.save(new User("viewer@verizon.com", "viewer", new HashSet<>(Arrays.asList(roleRepository.findByRole(ROLE_TYPE.VIEWER).get()))));
    }
}
