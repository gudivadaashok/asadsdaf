package com.verizon.npi.mvc.core.users;

import com.verizon.npi.mvc.dao.oracle.RoleRepository;
import com.verizon.npi.mvc.dao.oracle.UserRepository;
import com.verizon.npi.mvc.models.oracle.User;
import com.verizon.npi.mvc.models.sub.ROLE_TYPE;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;
    private RoleRepository roleRepository;
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    public static final String TOKEN_INVALID = "invalidToken";
    public static final String TOKEN_EXPIRED = "expired";
    public static final String TOKEN_VALID = "valid";

    @Autowired
    public UserServiceImpl(UserRepository userRepository,
                           RoleRepository roleRepository,
                           BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.bCryptPasswordEncoder = bCryptPasswordEncoder;
    }

    @Override
    public User save(User user) {
        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        user.setRoles(user.getRoles() != null && !user.getRoles().isEmpty() ? user.getRoles() : new HashSet<>(Collections.singleton(roleRepository.findByRole(ROLE_TYPE.USER).get())));
        User newUser = userRepository.save(user);
        return newUser;
    }

    @Override
    public List<User> save(List<User> user) {
        List<User> users = userRepository.save(user
                .stream()
                .map(e -> {
            e.setPassword(bCryptPasswordEncoder.encode(e.getPassword()));
            e.setRoles(e.getRoles() != null && !e.getRoles().isEmpty() ? e.getRoles() : new HashSet<>(Collections.singleton(roleRepository.findByRole(ROLE_TYPE.USER).get())));
            return e;
        }).collect(Collectors.toList()));

        return users;
    }

    @Override
    public User save(User user, List<ROLE_TYPE> role) {
        user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
        user.setRoles(new HashSet<>(roleRepository.findByRoles(role)));
        User newUser = userRepository.save(user);
        return newUser;
    }

    @Override
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Override
    public void deleteUser(List<Long> userids) {
        userRepository.delete(userRepository.findAll(userids));
    }


    @Override
    public Optional<User> findUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

}
