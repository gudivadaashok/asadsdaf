package com.verizon.npi.mvc.core;

public class NpiConfiguration {

    public static String NPI_AUTH_HEADER = "NpiAuthToken";
}
