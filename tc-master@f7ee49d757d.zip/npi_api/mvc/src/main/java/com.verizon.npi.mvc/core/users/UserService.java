package com.verizon.npi.mvc.core.users;


import com.verizon.npi.mvc.models.oracle.User;
import com.verizon.npi.mvc.models.sub.ROLE_TYPE;

import java.util.List;
import java.util.Optional;

public interface UserService {

    List<User> save(List<User> user);

    User save(User user, List<ROLE_TYPE> role);

    User save(User user);

    Optional<User> findByUsername(String username);

    void deleteUser(List<Long> userids);

    Optional<User> findUserByEmail(String email);

}
