package com.verizon.npi.mvc;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.websocket.WebSocketAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * Created by Cherla, Arun on 5/6/2018.
 */

@SpringBootApplication(scanBasePackages = "com.verizon", exclude = {WebSocketAutoConfiguration.class})
@EnableAspectJAutoProxy(proxyTargetClass=true)
public class Application {
    public static void main(String[] args) {
        new SpringApplicationBuilder(Application.class)
                .web(true)
                .run(args);
    }
}
