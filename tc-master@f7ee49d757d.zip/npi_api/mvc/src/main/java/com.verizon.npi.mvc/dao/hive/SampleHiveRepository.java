package com.verizon.npi.mvc.dao.hive;

import com.verizon.npi.mvc.models.hive.SampleHiveTable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by Cherla, Arun on 5/11/2018.
 */
@Repository
public interface SampleHiveRepository extends JpaRepository<SampleHiveTable, Long> {
}
