package com.verizon.npi.mvc.dao.oracle;

import com.verizon.npi.mvc.models.oracle.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    @Transactional
    @Query("SELECT r FROM User r WHERE r.username = :username")
    Optional<User> findByUsername(@Param("username") String username);

    @Transactional
    @Query("SELECT r FROM User r WHERE r.email = :email")
    Optional<User> findByEmail(@Param("email") String email);

    @Transactional
    @Query("SELECT r FROM User r WHERE r.id = :id")
    User findUserById(@Param("id") Long id);

    @Transactional
    @Query("SELECT r FROM User r WHERE r.id IN :ids")
    List<User> findUserByIds(@Param("ids") List<Long> id);
}
