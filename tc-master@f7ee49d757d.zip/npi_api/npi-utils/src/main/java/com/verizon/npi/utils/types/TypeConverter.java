package com.verizon.npi.utils.types;

public interface TypeConverter<T>{
    T convert(String s);
}