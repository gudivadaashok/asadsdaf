package com.verizon.npi.utils.types;

import java.util.HashMap;
import java.util.Map;

public class TypeConverterFactory{
        private Map<Class<?>, TypeConverter<?>> map = new HashMap<>();

        static public final TypeConverterFactory FACTORY = new TypeConverterFactory();

        private  TypeConverterFactory(){
            init();
        }

        private void init() {
            map.put(Double.class, s -> s == null ?  null : Double.parseDouble(s));
            map.put(String.class, s -> s );
            map.put(Integer.class, s -> s == null ?  null : Integer.parseInt(s));
            map.put(Long.class, s -> s == null ?  null : Long.parseLong(s));
        }

        @SuppressWarnings("unchecked")
		public <T> TypeConverter<T> getConverter(Class<T> tClass){
            return (TypeConverter<T>) map.get(tClass);
        }
    }