package com.verizon.npi.utils.types;

public class StringFunctions {

    public static String concat(Object... args){
        String _return_string = null;
        for(Object val : args){
            _return_string = _return_string.concat(String.valueOf(val));
        }
        return _return_string;
    }
}
