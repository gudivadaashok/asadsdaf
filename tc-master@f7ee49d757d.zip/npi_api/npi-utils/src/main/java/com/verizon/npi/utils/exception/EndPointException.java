package com.verizon.npi.utils.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value= HttpStatus.INTERNAL_SERVER_ERROR, reason="Processing Error :")
public class EndPointException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public EndPointException() {
        super();
    }
    public EndPointException(String message, Throwable cause) {
        super(message, cause);
    }

    public EndPointException(String message) {
        super(message);
    }
    public EndPointException(Throwable cause) {
        super(cause);
    }

}
