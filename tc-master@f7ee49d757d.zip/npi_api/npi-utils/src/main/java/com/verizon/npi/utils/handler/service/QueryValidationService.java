package com.verizon.npi.utils.handler.service;

/**
 * Created by Cherla, Arun on 4/1/2017.
 */
public interface QueryValidationService {
    public boolean validate(String query);

}
