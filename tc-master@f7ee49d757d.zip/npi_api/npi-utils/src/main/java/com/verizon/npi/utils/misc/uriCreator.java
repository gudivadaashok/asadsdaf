package com.verizon.npi.utils.misc;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Cherla, Arun on 4/15/2017.
 */
public class uriCreator {

    public static String createUri(String url, Map<String, String> params) {
        StringBuilder sb = new StringBuilder();
        for(HashMap.Entry<String, String> e : params.entrySet()){
            if(sb.length() > 0){
                sb.append('&');
            }
            try {
                sb.append(URLEncoder.encode(e.getKey(), "UTF-8")).append('=').append(e.getValue());
            } catch (UnsupportedEncodingException e1) {
                e1.printStackTrace();
            }
        }

        return url + "?" + sb.toString();
    }

    public static String createUriWithDuplicates(String url, List<String> params) {
        StringBuilder sb = new StringBuilder();
        for(String e : params){
            if(sb.length() > 0){
                sb.append('&');
            }
            try {
                sb.append(URLEncoder.encode(e.split("|")[0], "UTF-8")).append('=').append(e.split("|")[1]);
            } catch (UnsupportedEncodingException e1) {
                e1.printStackTrace();
            }
        }
        return url + "?" + sb.toString();
    }
}
