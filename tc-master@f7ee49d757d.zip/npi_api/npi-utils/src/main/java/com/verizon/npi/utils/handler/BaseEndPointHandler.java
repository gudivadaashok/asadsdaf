package com.verizon.npi.utils.handler;

import com.verizon.npi.utils.exception.EndPointException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BaseEndPointHandler{

    private static final Logger log = LoggerFactory
            .getLogger(BaseEndPointHandler.class.getName());

    protected interface RestAction<T> {
        T execute() throws Exception;
    }

    protected interface RestUpdate {
        void execute() throws Exception ;
    }

    protected <T> T execute(RestAction<T> a) {
        try {
            return a.execute() ;
        } catch( Throwable err ) {
            log.error(err.getMessage(), err);
            throw new RuntimeException(err.getMessage()) ;
        }
    }

    protected void update(RestUpdate update) throws EndPointException {
        try {
            update.execute() ;
        } catch( Throwable err ) {
            log.error(err.getMessage(), err);
            throw new EndPointException(err.getMessage()) ;
        }
    }


}
