package com.verizon.npi.utils.exception;

/**
 * Created by Cherla, Arun on 4/5/2017.
 */
public class NoSuchProcess {
    private static final long serialVersionUID = 1L;
    private final String typeName;
    private final String name;

    public NoSuchProcess(Class<?> type, String name) {
        this.typeName = type.getName();
        this.name = name;
    }

    public String getTypeName() {
        return typeName;
    }

    public String getName() {
        return name;
    }
}
