package com.verizon.npi.utils.aggregator;

/**
 * Created by Cherla, Arun on 4/6/2017.
 */
public interface Reducer<S, D> {

    public void add(S val) ;
    public D apply() ;

}