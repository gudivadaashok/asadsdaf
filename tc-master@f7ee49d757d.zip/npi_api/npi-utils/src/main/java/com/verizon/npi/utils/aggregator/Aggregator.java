package com.verizon.npi.utils.aggregator;

/**
 * Created by Cherla, Arun on 4/6/2017.
 */
public interface Aggregator<T> extends Reducer<T, T> {

}
