#!/bin/ksh
export OPT=$1
export PORT=9048
export JVM_OPTS="-server -Xms512m -Xmx2g -XX:+UseParNewGC -XX:+UseConcMarkSweepGC -XX:+UseTLAB -XX:NewSize=128m -XX:MaxNewSize=128m -XX:MaxTenuringThreshold=0 -XX:SurvivorRatio=1024 -XX:+UseCMSInitiatingOccupancyOnly -XX:CMSInitiatingOccupancyFraction=40 -XX:MaxGCPauseMillis=1000 -XX:InitiatingHeapOccupancyPercent=50 -XX:+UseCompressedOops -XX:ParallelGCThreads=8 -XX:ConcGCThreads=8 -XX:+DisableExplicitGC -Dspring.profiles.active=default"

export ML_PID=`ps -aef | grep java | grep mvc-1.0-SNAPSHOT.jar | grep -v grep | awk '{print $2}'`

case $OPT in 
start)
			if [ -z "$ML_PID" ]; then
				echo -e "`date`: starting WebTest process"
				java -jar ${JVM_OPTS} ${WORKSPACE}/target/mvc-1.0-SNAPSHOT.jar  2>&1 > /dev/null &
			else
				echo -e "`date`: WebTest process is already running with PID=$ML_PID"
			fi
;;
stop)
			if [ ! -z "$ML_PID" ]; then
				echo -e "`date`: stopping WebTest process"
				kill $ML_PID
                                sleep 10
                                ML_PID=`ps -aef | grep java | grep mvc-1.0-SNAPSHOT.jar | grep -v grep | awk '{print $2}'`
				if [ ! -z "$ML_PID" ]; then
					kill -9 $ML_PID
				fi
                        else
				echo -e "`date`: WebTest process is not running"
			fi	
;;
status)
			if [ -z "$ML_PID" ]; then
				echo -e "`date`: WebTest process is down"
			else
				echo -e "`date`: WebTest process is running with PID=$ML_PID"
			fi
			
;;	
monitor)
			if [ -z "$ML_PID" ]; then
				echo -e "`date`: WebTest process is down.. Restarting WebTest"
				java -jar ${JVM_OPTS} ${WORKSPACE}/target/mvc-1.0-SNAPSHOT.jar  2>&1 > /dev/null &
			else
				echo -e "`date`: WebTest process is running with PID=$ML_PID"
                                grep -i "java.lang.OutOfMemoryError" ${ML_LOGS}
                                if [ $? -eq 0 ];then
				 echo "delphiML is out of memory"
				 mailx -s "$HOSTNAME:WebTest is out of memory" ${EMAIL} < ${ML_LOGS}
				 ML_PID=`ps -aef | grep java | grep mvc-1.0-SNAPSHOT.jar | grep -v grep | awk '{print $2}'`
				     if [ ! -z "$ML_PID" ]; then
					kill -9 $ML_PID
                                        sleep 20
                                        mv ${ML_LOGS} ${ML_LOGS}.$$
					java -jar ${JVM_OPTS} ${WORKSPACE}/target/mvc-1.0-SNAPSHOT.jar  2>&1 > /dev/null &
					fi
			          fi
		        fi
			
;;

*)
		echo -e "Usage $0 start/stop/status/monitor"
esac
